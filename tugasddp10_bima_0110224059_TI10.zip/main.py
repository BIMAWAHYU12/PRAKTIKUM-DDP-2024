
from aritmatika_modul import *  
from bangun_ruang import *  
from bangun_datar import * 

def hitungan_aritmatika():
    print("\nPilih operasi aritmatika yang ingin dilakukan:")
    print("1. Penjumlahan")
    print("2. Pengurangan")
    print("3. Perkalian")
    print("4. Pembagian")
    print("5. Pangkat")
    print("6. Hitung Luas Bangun Datar")
    print("7. Hitung Luas Bangun Ruang")
    print("8. Keluar")
    
    pilihan = int(input("\nMasukan nomor operasi aritmatika yang dipilih (1-8): "))

    if pilihan == 1:
        a = int(input("Masukan angka pertama: "))
        b = int(input("Masukan angka kedua: "))
        print("Hasil penjumlahan:", tambah(a, b))
    elif pilihan == 2:
        a = int(input("Masukan angka pertama: "))
        b = int(input("Masukan angka kedua: "))
        print("Hasil pengurangan:", kurang(a, b))
    elif pilihan == 3:
        a = int(input("Masukan angka pertama: "))
        b = int(input("Masukan angka kedua: "))
        print("Hasil perkalian:", kali(a, b))
    elif pilihan == 4:
        a = int(input("Masukan angka pertama: "))
        b = int(input("Masukan angka kedua: "))
        print("Hasil pembagian:", bagi(a, b))
    elif pilihan == 5:
        a = int(input("Masukan angka pertama: "))
        b = int(input("Masukan angka kedua: "))
        print("Hasil eksponensial:", pangkat(a, b))
    elif pilihan == 6:
        print("\nPilih bangun datar yang ingin dihitung luasnya:")
        print("1. Persegi")
        print("2. Persegi Panjang")
        print("3. Segitiga")
        print("4. Lingkaran")
        print("5. Trapesium")
        pilihan_bangun_datar = int(input("\nMasukkan pilihan (1-5): "))
        
        if pilihan_bangun_datar == 1:
            sisi = int(input("Masukan sisi persegi: "))
            print("Luas persegi:", luas_persegi(sisi))
        elif pilihan_bangun_datar == 2:
            panjang = int(input("Masukan panjang persegi panjang: "))
            lebar = int(input("Masukan lebar persegi panjang: "))
            print("Luas persegi panjang:", luas_persegi_panjang(panjang, lebar))
        elif pilihan_bangun_datar == 3:
            alas = int(input("Masukan alas segitiga: "))
            tinggi = int(input("Masukan tinggi segitiga: "))
            print("Luas segitiga:", luas_segitiga(alas, tinggi))
        elif pilihan_bangun_datar == 4:
            jari_jari = int(input("Masukan jari-jari lingkaran: "))
            print("Luas lingkaran:", luas_lingkaran(jari_jari))
        elif pilihan_bangun_datar == 5:
            alas_bawah = int(input("Masukan alas bawah trapesium: "))
            alas_atas = int(input("Masukan alas atas trapesium: "))
            tinggi = int(input("Masukan tinggi trapesium: "))
            print("Luas trapesium:", luas_trapesium(alas_bawah, alas_atas, tinggi))
        else:
            print("Pilihan tidak valid.")
    
    elif pilihan == 7:
        print("\nPilih bangun ruang yang ingin dihitung luas permukaannya:")
        print("1. Balok")
        print("2. Kubus")
        print("3. Bola")
        print("4. Tabung")
        print("5. Kerucut")
        pilihan_bangun_ruang = int(input("\nMasukkan pilihan (1-5): "))
        
        if pilihan_bangun_ruang == 1:
            panjang = int(input("Masukan panjang balok: "))
            lebar = int(input("Masukan lebar balok: "))
            tinggi = int(input("Masukan tinggi balok: "))
            print("Luas permukaan balok:", luas_permukaan_balok(panjang, lebar, tinggi))
        elif pilihan_bangun_ruang == 2:
            sisi = int(input("Masukan sisi kubus: "))
            print("Luas permukaan kubus:", luas_permukaan_kubus(sisi))
        elif pilihan_bangun_ruang == 3:
            jari_jari = int(input("Masukan jari-jari bola: "))
            print("Luas permukaan bola:", luas_permukaan_bola(jari_jari))
        elif pilihan_bangun_ruang == 4:
            jari_jari = int(input("Masukan jari-jari tabung: "))
            tinggi = int(input("Masukan tinggi tabung: "))
            print("Luas permukaan tabung:", luas_permukaan_tabung(jari_jari, tinggi))
        elif pilihan_bangun_ruang == 5:
            jari_jari = int(input("Masukan jari-jari kerucut: "))
            tinggi = int(input("Masukan tinggi kerucut: "))
            print("Luas permukaan kerucut:", luas_permukaan_kerucut(jari_jari, tinggi))
        else:
            print("Pilihan tidak valid.")
    
    elif pilihan == 8:
        print("Program selesai, terima kasih!")
        return
    else:
        print("Pilihan tidak valid. Coba lagi.")

    hitungan_aritmatika()  

hitungan_aritmatika()
