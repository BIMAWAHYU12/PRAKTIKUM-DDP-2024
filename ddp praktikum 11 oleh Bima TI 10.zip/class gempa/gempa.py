class Gempa:
    # Konstruktor untuk inisialisasi atribut lokasi dan skala
    def __init__(self, lokasi, skala):
        self.lokasi = lokasi
        self.skala = skala

    # Method untuk menentukan dampak gempa
    def dampak(self):
        if self.skala < 2:
            dampak = "tidak berasa"
        elif 2 <= self.skala <= 4:
            dampak = "menyebabkan bangunan retak-retak"
        elif 4 < self.skala <= 6:
            dampak = "menyebabkan bangunan roboh"
        else:  # self.skala > 6
            dampak = "menyebabkan tsunami"

        # Menampilkan informasi lokasi dan skala
        print(f"Dampak gempa: {dampak}")
        print(f"Lokasi gempa: {self.lokasi}")
        print(f"Skala gempa: {self.skala}")
