from gempa import Gempa  # Impor kelas Gempa dari file gempa.py

# Membuat objek gempa dengan lokasi dan skala tertentu
gempa1 = Gempa("banten", 1.2)
gempa2 = Gempa("palu", 6.1)
gempa3 = Gempa("cianjuar", 5.6)
gempa4 = Gempa("jayapura", 3.3)
gempa5 = Gempa("garut", 4.0)

# Menampilkan dampak gempa untuk setiap objek
print("Informasi Gempa 1:")
gempa1.dampak()
print("\nInformasi Gempa 2:")
gempa2.dampak()
print("\nInformasi Gempa 3:")
gempa3.dampak()
print("\nInformasi Gempa 4:")
gempa4.dampak()
print("\nInformasi Gempa 5:")
gempa5.dampak()
